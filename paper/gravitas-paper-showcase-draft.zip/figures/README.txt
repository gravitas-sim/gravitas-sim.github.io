Place the four final PNG screenshots in this directory using the exact filenames in FIGURE_CAPTURE_GUIDE.md.
